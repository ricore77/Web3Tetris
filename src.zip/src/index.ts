console.log("Web3Tetris application started.");
