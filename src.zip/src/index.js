"use strict";
console.log("Web3Tetris application started.");
//# sourceMappingURL=index.js.map